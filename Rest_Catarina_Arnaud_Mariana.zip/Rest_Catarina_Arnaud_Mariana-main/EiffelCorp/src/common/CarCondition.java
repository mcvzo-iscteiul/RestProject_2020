package common;

public enum CarCondition {
	PERFECT, GOOD, OK, BAD, AWFULL
}
