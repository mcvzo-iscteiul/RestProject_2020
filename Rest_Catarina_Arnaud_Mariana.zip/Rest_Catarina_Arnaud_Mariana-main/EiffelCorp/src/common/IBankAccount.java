package common;

public interface IBankAccount {
	
	public String getRib();
	public double getBalance();
	public void setRib(String rib);
	public void setBalance(double balance);
	
}